

public class Main {
    public static void main(String[] args) {
        double oWallet = 500;
        mpg car1 = new mpg(12.5, 24, 12.5,oWallet);
        System.out.println(car1);
        int stops = 0;
        while(car1.getWallet()>50){
            double distance = ((int)((Math.random()*250)+50)*100)/100.0;
            double price = (int)((Math.random()*1.8+2.49)*100)/100.0;
            double gallons = ((int)(Math.random()*13.5)*100)/100.0;
            car1.drive(distance);car1.fillUp(distance,price);stops++;
        }
        System.out.println(car1.getWallet());
        double avgPrice = ((int)((oWallet-car1.getWallet())/(car1.gettMiles()/24)*100))/100.0;
        System.out.println("You drove: "+car1.gettMiles()+" miles and made "+stops+" stops!");
        System.out.println("You averaged: "+((int)((car1.gettMiles()/stops)*100))/100.0+" miles between stops!");
        System.out.println("The average price of gas was: $"+ avgPrice + " per gallon!");
    }

}

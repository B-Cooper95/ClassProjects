

public class mpg {
    private double tank;
    private double tMax;
    private double mileage;
    private double toEmpty;
    private double tMiles;
    private double wallet;
    private double cost;

    public mpg(double t, double m, double tm, double w){
        tank = t;
        mileage = m;
        tMax = tm;
        wallet = w;
        tMiles=0;
        toEmpty = ((int)(mileage*tank*100))/100.0;
    }
    public mpg(double t, double m, double tm){
        tank = t;
        mileage = m;
        tMax = tm;
        tMiles=0;
        wallet = 500.0;
        toEmpty = ((int)(mileage*tank*100))/100.0;
    }
    public double getTank(){
        return tank;
    }
    public double getMileage(){
        return mileage;
    }
    public double gettMax() {
        return tMax;
    }
    public double getToEmpty() {
        return toEmpty;
    }
    public double gettMiles() {
        return tMiles;
    }

    public double getWallet() {
        return wallet;
    }

    public String toString(){
        return "Max Tank Level: "+tMax+  " gals\nMiles per Gallon: "+mileage+
                " mi\nGas in Tank: " + tank +" gals\nMiles to Empty: "+toEmpty+
                " mi\nMoney for Trip: $"+wallet+"\n";
    }

    public void setMileage(double mileage) {
        this.mileage = mileage;
    }
    public void setTank(double tank) {
        this.tank = tank;
    }
    public void settMax(double tMax) {
        this.tMax = tMax;
    }

    public void setToEmpty() {
        toEmpty = ((int)(mileage*tank*100))/100.0;
        System.out.println("Miles to Empty: "+toEmpty+"mi\n");
    }
    public void setWallet(){
        wallet-=cost;
        wallet = ((int)(wallet*100))/100.0;
        System.out.println("Money left: "+wallet);
    }

    public void tMiles(double m){
        tMiles += m;
    }

    public void drive(double miles){
        if(toEmpty <= miles){
            System.out.print("After "+toEmpty+" miles, ");
            toEmpty = 0; tank = 0; tMiles(toEmpty);
            System.out.println("You ran out of gas!\n");
        }else {
            toEmpty -= miles;
            tank = (int)(toEmpty*100 / mileage)/100.0;
            System.out.println("You drove: "+miles+"mi");
            System.out.println("Gas Tank: " + tank+" gals");
            setToEmpty(); tMiles(miles);
        }
    }

    public void fillUp(double gallons) {
        if(gallons<=0){
            System.out.println("You bought no gas.");
        }else if(tank+gallons >= tMax){
            System.out.println("You bought "+(tMax-tank)+" gallons.");
            tank = tMax;
        }else{
            tank+=gallons;
            System.out.println("You bought "+gallons+" gallons.");
        }
        setToEmpty();
    }
    public void fillUp(double gallons, double price) {
        if(gallons<=0){
            System.out.println("You bought no gas.");
        }else if(tank+gallons >= tMax){
            System.out.println("You bought "+(tMax-tank)+" gallons at $"+price+" per gallon.");
            cost = ((int)((tMax-tank)*price*100))/100.0;
            tank = tMax;
        }else{
            tank+=gallons;
            cost = ((int)(gallons*price*100))/100.0;
            System.out.println("You bought "+gallons+" gallons at $"+price+" per gallon.");
        }

        System.out.println("It costed: $"+cost);
        setToEmpty(); setWallet();
    }



}

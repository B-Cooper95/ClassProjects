package SearchSort;

import java.util.ArrayList;
import java.util.Arrays;

public class SelectionSort {
/*

Selection sort is an in-place comparison sorting algorithm. It has an O(n²) time complexity,
which makes it inefficient on large lists, and generally performs worse than the similar insertion sort.
Works by comparing the value in a list i to see if the it is occupying the best position.
It does this by asking every comparing every value j after it. If j is less than i, than i and j swap places.


Test Values:
23,2,10,5,2,15,19,99,75,43,110,3574,842,013,54,1
15,14,13,12,11,10,9,8,7,6,5,4,3,2,1
1,2,3,4,5,6,7,8,9,10,11,12,13,14,15

 */

    public static void main(String[] args) {

        ArrayList<Integer> L = new ArrayList<Integer>(Arrays.asList(15,14,13,12,11,10,9,8,7,6,5,4,3,2,1));
        selectionSort(L);



    }


    public static void selectionSort(ArrayList<Integer> list){
        System.out.println("\n\n"+list);
        int swaps=0; int passes = 0; int comparisons = 0;

        for(int i =0; i < list.size(); i++){
            boolean sorted = true;
            passes++;
            int temp = i;
            for(int j = i+1; j < list.size(); j++){
                comparisons++;
                if(list.get(j) < list.get(temp)){
                    temp = j;
                    sorted = false;
                }
            }
            if(sorted == false) {
                int tempVal = list.get(temp);
                list.set(temp, list.get(i));
                list.set(i, tempVal);
                swaps++;
                System.out.println(list);
            }
        }
        System.out.println(list+"\n\nList Size: "+list.size()+"\nPasses: "+passes+"\nComparisons: "+comparisons+"\nSwaps: "+swaps);
    }


}

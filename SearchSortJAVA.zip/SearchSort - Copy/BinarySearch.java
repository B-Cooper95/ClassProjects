

import java.util.ArrayList;
import java.util.Arrays;

public class BinarySearch {

    public static void main(String[] args) {

           int[] l1 = {1,3,5,7,10,13,14,20,25};
           binarySearch(l1, 14);

    }

    public static int binarySearch(int[] arr, int target){
        int left = 0; int right = arr.length-1;
        int tries = 0;
        while(left<=right){
            int mid = (left+right)/2; tries++;
            System.out.println("Trying idx: "+mid+"  Value: "+arr[mid]+"\nLeft: "+left+"  Right: "+right);
            if(arr[mid] == target){
                System.out.println("It took "+tries+" tries to find the value at position "+mid);
                return mid;
            }
            else if(arr[mid] < target){
                left = mid+1;
            }
            else if(arr[mid] > target){
                right = mid-1;
            }
            

        }
        System.out.println("Value not found\nTries: "+tries);
        return -1;
    }


}

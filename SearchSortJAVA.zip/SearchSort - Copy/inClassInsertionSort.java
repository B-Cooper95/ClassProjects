package SearchSort;

import java.util.ArrayList;
import java.util.Arrays;

public class inClassInsertionSort {
    /*
    Insertion sort iterates, consuming one input element each repetition, and grows a sorted output list.
    At each iteration, insertion sort removes one element from the input data, finds the location it belongs
    within the sorted list, and inserts it there. It repeats until no input elements remain.

    Insertion sort works by comparing the value of each element i to each value j that precedes it.
    Each i is copied to a temporary variable called "best" as in:
    Is this the best spot?
    Each value of i, arr[i], is stored in a variable called "temp".
    int best = i; int temp = arr.get(i)

    For each value i, we enter and remain in a while loop under 2 assumptions:
    That best is greater than 0
    That the value of temp is greater than the value arr.get(best-1)
        Note: Best is decremented each run through.


    If we are ordering in ascending value, if i is less than any value that precedes it, it will shift
    to the spot which is most suitable for it.


    Test Values:
    23,2,10,5,2,15,19,99,75,43,110,3574,842,013,54,1
    15,14,13,12,11,10,9,8,7,6,5,4,3,2,1
    1,2,3,4,5,6,7,8,9,10,11,12,13,14,15


     */
    public static void main(String[] args) {

        ArrayList<Integer> L = new ArrayList<Integer>(Arrays.asList(5, 3, 7, 1, 9, 4));
        insertionSort(L);


    }

    public static void insertionSort(ArrayList<Integer> list) {
        for (int i = 1; i < list.size(); i++) {
            System.out.println(list);
            int best = i;
            int temp = list.get(i);
            System.out.println("\ni="+i+"\nTemp: "+temp+"\n"+list+"\n");
            while (best > 0 && temp < list.get(best - 1)) {
                //System.out.println("Best: "+best+"\nValue: "+list.get(best));
                list.set(best, list.get(best-1));
                best--;
                System.out.println(list);
            }
            list.set(best, temp) ;



        }
        System.out.println(list + "\n\nList Size: " + list.size());

    }

}
package SearchSort;

public class LinearSearch {

    public static void main(String[] args) {
        int[] l1 = {7,5,1,2,4,6,3,7};
        System.out.println(linearSearch(l1, 6));
    }

    public static int linearSearch(int[] array, int target){
        for(int i=0; i<array.length;i++){
            if(array[i] == target)
                return i;
        }
        return -1;
    }

}

package SearchSort;

public class inClassSearchBinary {

    public static void main(String[] args) {
        int[] l1 = {1,3,5,6,10,13,14,20,25};

        System.out.println(binarySearch(l1, 30));
    }

    public static int binarySearch(int[] arr, int target){
        //All boundaries represent index values.
        int left = 0; int right = arr.length-1;
        int tries = 0;
        while(left<=right){
            int mid = (left+right)/2;
            tries++;
            System.out.println("Val: "+arr[mid]+"\nLeft: "+left+"\nMid: "+mid+"\nRight: "+right+"\n");
            if(arr[mid]==target) {
                System.out.println(target + " was found, it took " + tries + " tries!");
                return mid;
            }else if(arr[mid] < target)
                left = mid+1;
            else if(arr[mid] > target)
                right = mid-1;

        }
        System.out.println(target + " was not found, it took " + tries + " tries!");
      return -1;  
    }





}

package SearchSort;

import java.util.ArrayList;
import java.util.Arrays;

public class removeVal {

    public static void main(String[] args) {
        ArrayList<Integer> l1 = new ArrayList<Integer>(Arrays.asList(7,5,1,2,4,6,3,7));
        l1 = linearSearch(l1, 7);
        System.out.println(l1);
    }

    public static ArrayList<Integer> linearSearch(ArrayList<Integer> array, int target){
        for(int i=0; i<array.size();i++){
            if(array.get(i) == target){
                array.remove(i);
                i--;
            }
        }
        return array;
    }

}

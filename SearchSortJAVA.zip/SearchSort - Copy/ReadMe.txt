Various searching and sorting programs and lessons for students to learn about their differences.
Gives us the context for understanding Big O
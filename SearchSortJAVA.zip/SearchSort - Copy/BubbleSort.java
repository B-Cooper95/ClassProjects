package SearchSort;
import java.util.Arrays;
import java.util.Scanner;

/*
Bubble sort, sometimes referred to as sinking sort, is a simple sorting algorithm
that repeatedly steps through the list, compares adjacent elements and swaps them
if they are in the wrong order. The pass through the list is repeated until the
list is sorted.

23,2,10,5,2,15,19,99,75,43,110,3574,842,013,54,1
15,14,13,12,11,10,9,8,7,6,5,4,3,2,1
1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
5,3,7,1,2,4
 */


public class BubbleSort {
    public static int x = 0;

    public static void main(String[] args) {
        arr(new int[]{5,3,7,1,2,4});


    }
    public static void arr(int[] array) {
        boolean sorted = false;
        System.out.println(Arrays.toString(array));

        while (sorted == false) {
            sorted = true;
            for (int i = 0; i < array.length - 1; i++) {
                if (array[i] < array[i + 1]) {
                    System.out.println(Arrays.toString(array));
                    sorted = false;
                    x = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = x;
                }
            }
        }
        System.out.println(Arrays.toString(array));
    }
}

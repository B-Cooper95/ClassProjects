package SearchSort;

import java.util.ArrayList;
import java.util.Arrays;

public class inClassSelectionSort {

    public static void main(String[] args) {
        ArrayList<Integer> L = new ArrayList<Integer>(Arrays.asList(5, 3, 7, 1, 2, 4));
        selectionSort(L);
    }

    public static void selectionSort(ArrayList<Integer> list) {
        System.out.println(list);
        for (int i = 0; i < list.size(); i++) {
            boolean sorted = true;
            int temp = i;
            for (int j = i + 1; j < list.size(); j++) {
                if (list.get(j) < list.get(temp)) {
                    temp = j;
                    sorted = false;
                }
            }
            if(!sorted) {
                int tempVal = list.get(temp);
                list.set(temp, list.get(i));
                list.set(i, tempVal);
                System.out.println(list);
            }
        }


    }


}
